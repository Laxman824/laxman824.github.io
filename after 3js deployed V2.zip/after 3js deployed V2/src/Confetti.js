// import React, { useEffect, useRef } from 'react';
// import Confetti from 'react-confetti';

// const ConfettiComponent = () => {
//   const confettiRef = useRef();

//   useEffect(() => {
//     console.log("Running confetti animation"); // Added console log

//     const runConfetti = () => {
//       confettiRef.current.confetti({
//         particleCount: 100, // Adjust the number of confetti pieces
//         colors: ['#f14', '#f59', '#f9c', '#ffe'], // Set confetti colors
//       });
//     };

//     runConfetti();
//   }, []);

//   return (
//     <Confetti ref={confettiRef} />
//   );
// };

// export default ConfettiComponent;
