# Portfolio

![Hits](https://hitcounter.pythonanywhere.com/count/tag.svg?url=https%3A%2F%2Fgithub.com%2FHrishi1999%2FopPortfolio)

![opPortfolio](/images/portfolio.gif)
# Command useful 

Clone this repo
Run npm i
Check it out using npm start
If this doesn't work Just change the location of the file download and repeat process

# How to Deploy

I have used Netlify to host my portfolio. If you want to use GitHub Pages, just run `npm run build` and publish all the files in the `/build` folder to your repository.

# References


Illustrations: https://undraw.co/
#install some files  before runing to reduce dependecny issues 
npm install --legacy-peer-deps
npm install react-lottie emailjs-com react-hot-toast @emotion/react @emotion/styled --legacy-peer-deps